# Horizontal v3 firmware — 10 Hz / 10 ms

This release targets the horizontal v3 STM32H563RGT6 carrier with eight v2
VL53L8CX boards. Build profile: `BOARD=horiz3 AVOID=cp ORIENT=180 RATE=10 INTEG=10`.

## 2026-09-11 UART update

The horizontal v3 raw point-cloud stream now sends 10 packets/s, matching the
configured sensor rate. Acquisition still polls at 20 Hz so it can collect
staggered sensor arrivals. Each UART packet combines the latest newly received
reading from each channel since the previous packet; an empty poll cannot erase
an unsent reading. Channels without new data have their freshness bit cleared.
Delayed samples expire, and a delayed UART task does not send catch-up bursts.
The packet timestamp and attitude describe the latest acquisition poll, not
simultaneous exposure of all eight sensors. The binary protocol is unchanged.

Sensor integration remains 10 ms. Collision-prevention processing and its
10 Hz MAVLink `OBSTACLE_DISTANCE` output retain their existing timing. The
installer also explicitly prints OpenOCD's flash-bank result before validating
the layout, fixing a pre-flash failure with the tested ST OpenOCD build.

## Behavior changes

- All eight sensors use autonomous 8×8 ranging at 10 Hz, with four 10 ms
  sub-integrations per frame. Calculated exposure duty is 40%; input watts
  and usable range must be measured. This is a bench candidate, not a range
  or power guarantee.
- Weak, inconsistent and no-target readings no longer initialize directions
  as clear to 4 m. Unmeasured angular bins, masked returns, floor/ceiling
  exclusions, and returns beyond the configured range remain unknown.
- Valid status 5 or 9 measurements provide distances; positive measurements
  below 50 cm are retained. The advertised minimum is 2 cm. A positive range
  below that minimum is clamped to 2 cm rather than discarded. Status 9 can
  represent a merged target and is accepted as an obstacle, never as proof
  of clearance. No-return does not establish visibility to the maximum range.
- The ST driver's target-count output is enabled, so no-target zones are
  normalized to status 255 instead of trusting a leftover distance/status.
- The avoidance path retains the latest frame independently for each sensor
  between polls. It expires that frame 200 ms after the successful polling
  pass, even when the acquisition task stops producing data. Newly received invalid readings
  replace old valid readings immediately. The host timestamps each polling pass at completion; it does
  not compensate for exposure, transport delay, or vehicle motion.
- The raw browser protocol carries a per-packet fresh-channel bitmap; the
  horizontal v3 UART batches new readings from its faster acquisition polls.
  The VFH code also treats unknown sectors as blocked; the distributed
  build sends only `OBSTACLE_DISTANCE`, not VFH velocity setpoints.
- Startup and sensor recovery share configuration and readback checks for
  mode, rate, resolution, and integration. Saved zone masks retain their
  existing layout and orientation.

Unknown is intentional and may cause PX4 Collision Prevention to restrict
motion into open sky or poorly measured directions. This release does not
claim calibrated continuous angular coverage between individual zone rays.
Do not convert unknown back to clear just to remove those restrictions.

## Build and package

```sh
python3 tools/package-firmware.py --output /absolute/path/ascend-8tof-horizontal-v3-2026.09.11-uart10
```

The packager builds the fixed profile, extracts diagnostic addresses from its
exact ELF, copies the installer/docs, and creates a ZIP with checksums. Users
of the ZIP need Python and ST OpenOCD, not the source repository or ARM compiler.
Do not copy a manifest between firmware builds: its diagnostic addresses must
match the exact image. Use a new output directory and version for each release.

The hardware installer backs up flash, checks MCU/layout, verifies the programmed
image and sensor profile, and checks that the saved mask is unchanged. It never
changes security settings or option bytes. See `INSTALL.md` in the ZIP for the
public installation instructions.

## Validation scope

Host regressions exercise weak/no-target status handling, close obstacles,
masking, unmeasured gaps, floor rejection, missing frames, sample expiry,
new invalid data replacing old data, and millisecond rollover. Existing
protocol and orientation regressions also run. Installer tests cover corrupt
packages, incorrect manifests, backup/program failures, readback mismatches,
sensor configuration failures, and saved-configuration changes.

Installation and all-eight-sensor verification passed on two boards; a UART
capture on one measured 9.98 cloud packets/s. See the
[2026-09-11 validation record](VALIDATION.md). Range, optical
calibration, power consumption, recovery fault injection, and Windows/Linux
hardware installation are not established by compilation or host tests.

References: [ST sensor interpretation and timing](https://www.st.com/content/st_com/en/technical-documents/UM3109.html),
[MAVLink OBSTACLE_DISTANCE meanings](https://mavlink.io/en/messages/common.html#OBSTACLE_DISTANCE).
