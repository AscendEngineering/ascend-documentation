# Validation — 2026-09-11 UART 10 Hz update

Profile: horizontal v3, CP output, 180° orientation, 8×8 / 10 Hz / 10 ms.

The original 2026-09-10 firmware was installed successfully on macOS today.
Its complete flash backup, firmware readback checksum, all eight sensors'
configuration/startup, and preservation of saved masks passed. OpenOCD's
`flash banks` result must be explicitly printed for the installer's layout
check; the local installer now does so.

The UART update batches fresh channels from the 20 Hz acquisition polls into
10 Hz raw-cloud packets. Host regressions passed for staggered channels,
freshness reset, new invalid readings, sample expiry, missed deadlines,
service-task jitter and millisecond wrap. Existing protocol, orientation,
obstacle, sample-cache and 15 installer tests also passed.

## Hardware result

Firmware version `2026.09.11-10hz10ms-uart10` was installed and verified on
two horizontal v3 boards, each with eight v2 sensors, using ST OpenOCD on macOS.

- Full 1 MiB flash backup completed before programming.
- Program verification and the subsequent firmware SHA-256 readback passed:
  `b7d37112d6904b0b0cd5484ae3afa2e3a3ff6b1f1ddd590de5c4c8917edb8bff`.
- All eight sensors started, with autonomous mode, 64 zones, 10 Hz and
  10 ms integration confirmed by readback on both boards. Saved mask bytes
  were unchanged on both boards; their unique MCU IDs were different.
- Before the update, a 12-second FTDI capture measured 19.30 cloud packets/s.
- After the update, a 30-second FTDI capture on the first board received 299 CRC-valid cloud
  packets: 9.98 packets/s measured between the first and last arrivals, with
  zero sequence gaps and all eight channels reported online throughout.
- Host packet-arrival intervals varied from 31 to 167 ms; 10 Hz is the
  scheduled average rate, not a guarantee of precisely spaced UART arrivals.
- Fresh-channel delivery measured 8.91–9.95 updates/s across the individual
  channels. Each packet contains the latest newly collected reading per
  channel; it is not a synchronized exposure and need not update every channel.

The firmware built without compiler warnings. Power, outdoor range,
detection reliability, recovery fault injection, and Windows/Linux hardware
installation have not been measured in this check.
