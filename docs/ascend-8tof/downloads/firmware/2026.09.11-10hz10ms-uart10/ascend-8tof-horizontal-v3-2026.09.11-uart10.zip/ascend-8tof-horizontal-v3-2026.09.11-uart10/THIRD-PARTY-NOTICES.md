# Third-party notices

The firmware includes FreeRTOS Kernel under the MIT license; the original
license is included in `third-party/FreeRTOS-LICENSE.md`.

The VL53L8CX ULD and sensor firmware buffer carry STMicroelectronics copyright
notices. The copied source headers state:

> Copyright (c) 2021 STMicroelectronics. All rights reserved.
>
> This software is licensed under terms that can be found in the LICENSE file
> in the root directory of this software component.
> If no LICENSE file comes with this software, it is provided AS-IS.

The existing repository does not include a separate ST component LICENSE file.
These notices preserve the supplied provenance and do not grant additional
rights to ST's sensor firmware. The ST tools and drivers remain separately
installed software; this ZIP does not redistribute OpenOCD or STM32CubeIDE.
