# Install Ascend 8TOF firmware

This package is for the **horizontal v3 STM32H563RGT6 carrier with eight v2
VL53L8CX sensor boards**, using the verified 180° sensor-zone orientation.
It installs autonomous **8×8, 10 Hz per sensor, 10 ms per sub-integration**,
and sends MAVLink `OBSTACLE_DISTANCE` for PX4 Collision Prevention.
It does not install firmware on the flight controller.

## What you need

- The complete extracted ZIP, including `firmware.bin`, `manifest.json`,
  `install.py`, and `openocd-horiz3.cfg`. No firmware compiler is required.
- [Python 3.9 or newer](https://www.python.org/downloads/).
- An ST-Link programmer with its USB drivers/permissions configured.
- **ST OpenOCD with STM32H5 support**, including `interface/stlink-dap.cfg`
  and `target/stm32h5x.cfg`. ST's OpenOCD is available with
  [STM32CubeIDE](https://www.st.com/en/development-tools/stm32cubeide.html)
  or can be built from [ST's source](https://github.com/STMicroelectronics/OpenOCD).
  Stock OpenOCD 0.12 packages may lack this MCU. Use the executable and
  scripts from the same ST distribution. The tested version is
  `0.12.0+dev-00635-g0a084c293`.

The Python installer targets Windows, macOS, and Linux and passes automated
installer tests. The 2026-09-11 UART update passed end-to-end installation and
all-eight-sensor verification on macOS with ST OpenOCD. See `VALIDATION.md` for
the hardware checks and measured UART cadence. Windows/Linux launchers still
need an installation check on those operating systems. The package does not
bundle Python, OpenOCD, drivers, or download software automatically.

## Connect the board

Perform installation on the bench with the vehicle disarmed and propellers
removed. Supply the board through its normal **regulated 5 V input at J5**.
An FTDI UART cable is for viewing data; it is not the ST-Link programming cable.

Connect the ST-Link to J6 using these nets from the horizontal v3 PCB:

| J6 pin | Signal | ST-Link connection |
|---|---|---|
| 1 | GND | GND |
| 3 | SWDIO | SWDIO |
| 4 | SWCLK | SWCLK |
| 6 | +3V3 | Target-voltage sense / VTref |

Use pin 6 only as the programmer's voltage-sense reference, not as an external
power output into the board. Verify your particular ST-Link pinout. SWO
(J6 pin 2) and RESET (pin 5) are not required by this installer; it uses a
software reset. Connect only one ST-Link, or select a probe with `--serial`.
Close other debugger/programmer sessions before running the installer.

## Install

Open a terminal in the extracted folder. First check the download:

```sh
python3 install.py --check
```

On Windows use `py -3` in place of `python3`.

On macOS/Linux:

```sh
sh install.sh
```

On Windows (Command Prompt or PowerShell):

```bat
.\install.cmd
```

If OpenOCD is not on PATH, provide the executable and scripts paths. For
example, replace these placeholders with the paths inside your ST installation:

```sh
python3 install.py --board horizontal-v3 --openocd "/path/to/tools/bin/openocd" --scripts "/path/to/scripts"
```

Windows example:

```bat
py -3 install.py --board horizontal-v3 --openocd "C:\path\to\openocd.exe" --scripts "C:\path\to\scripts"
```

STM32CubeIDE may keep the scripts in the debug plugin's
`resources/openocd/st_scripts` folder, separate from the executable in the
external-tools OpenOCD plugin. Both paths can also be supplied through the
`OPENOCD` and `OPENOCD_SCRIPTS` environment variables.

The installer checks the firmware checksum, identifies the MCU and flash
layout, and displays the unique board ID. **Confirm the physical board is
horizontal v3:** a matching MCU alone cannot identify the PCB revision.
Type `INSTALL` when prompted. Automated bench runs can pass `--yes`.

It then:

1. Backs up the complete 1 MiB flash to a unique local directory.
2. Programs only the firmware region and verifies the written image.
3. Resets the board and waits for the sensors to start.
4. Reads back each sensor's mode, resolution, rate, and integration setting.
5. Compares the saved mask bytes before/after and reads back the installed
   firmware to verify its SHA-256 checksum.

Success requires **all eight sensors** to start with the expected profile.
Backups and logs are saved under `Ascend8TOF/backups` in your home folder;
`--backup-dir PATH` selects another location. Keep the backup outside the
release download folder. A failed verification returns a nonzero exit code;
read the logs before treating the board as ready.

## Check the output

Open [8TOF Field Mask](https://tools.ascendengineer.com/) in Chrome and connect
through the FTDI adapter at **921600 baud**. Check all eight channels and move
an object in front of each sensor. CH7/J8 is the nose, beneath the tip of the A.
The 2026-09-11 UART update sends approximately 10 point-cloud packets/s, while
the MCU continues polling at 20 Hz and each sensor ranges at 10 Hz. UART packets
combine fresh channel readings from those polls. The original 2026-09-10 image
sent a packet after every poll, so its dashboard counter reads approximately
20 Hz even though each sensor ranges at 10 Hz.

This version sends unknown for weak, missing, masked, expired, and unmeasured
angular directions. It does not assert that missing echoes mean clear to 4 m.
PX4 may restrict movement toward unknown directions. Do not enable
`CP_GO_NO_DATA` merely to hide missing measurements. Close valid obstacles
are retained; use deliberate zone masks for enclosure/airframe returns.

The packaged output is for PX4's Collision Prevention path; configure and
validate the flight controller separately. These bench checks do not establish
outdoor detection range, braking distance, or readiness for autonomous flight.

## Troubleshooting and rollback

- **OpenOCD/scripts not found:** use the explicit paths above. An older generic
  OpenOCD installation may be selected before ST OpenOCD on PATH.
- **No ST-Link/target:** check normal board power, VTref, common ground, cable
  orientation, USB drivers/permissions, and other active debugger sessions.
- **Unexpected MCU, flash layout, or protection:** stop. This installer never
  unlocks, regresses security, changes option bytes, or performs a mass erase.
- **Sensor verification fails:** programming may have succeeded while a sensor
  is disconnected. Read `verify-sensors.log`, check that all eight sensor
  boards are connected/powered, then retry. Preserve the backup.
- **Power savings or range uncertain:** measure supply voltage/current/watts
  with the same scene and peripherals, then compare detection reliability at
  known distances in both indoor and outdoor lighting.

For rollback, keep `before-flash.bin` and its `result.json`/logs together with
that board. A full-image restore writes the original mask too. Use a programmer
with STM32H563 support to write that board's backup at `0x08000000`, verify, and
reset; do not apply another board's backup or erase option bytes. The supplied
installer intentionally accepts only the checksummed release image.

## Publishing this package

Upload the complete ZIP and link this installation page in your docs. Keep
`manifest.json` and `SHA256SUMS` with the matching firmware. Publish the ZIP
checksum alongside its download link. Do not publish per-board backup folders:
those are created locally by the installer and can contain private settings.
Checksums detect corruption; they are not a publisher signature.
