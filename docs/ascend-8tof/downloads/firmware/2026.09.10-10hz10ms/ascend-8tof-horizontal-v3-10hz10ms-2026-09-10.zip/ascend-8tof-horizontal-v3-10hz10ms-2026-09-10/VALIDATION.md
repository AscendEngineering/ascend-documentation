# Validation — 2026-09-10

Profile: horizontal v3, CP output, 180° zone orientation, 8×8 / 10 Hz / 10 ms.

Passed:

- ARM firmware compilation and link (116,200 bytes text, 88 bytes data,
  114,212 bytes BSS).
- Obstacle regressions: invalid/no-target statuses, no input, offline sensor,
  masks, range/bearing placement, close distances, excluded elevation,
  unmeasured angular gaps, and VFH handling of explicit clear versus unknown.
- Sample-cache regressions: independent channel freshness, intervening polls,
  new invalid data replacing a previous valid range, expiry on acquisition
  stall, and uint32 millisecond wrap.
- Existing link protocol and orientation tests.
- Fifteen installer tests, including complete backup/success, corruption,
  unsupported manifest/layout, backup failure/truncation, programming failure,
  incorrect sensor profile, altered mask, and failed image readback.
- Python compilation, POSIX launcher syntax, whitespace checks, package
  checksums and the installer's offline package check.

The new installer was invoked on macOS with ST OpenOCD
0.12.0+dev-00635-g0a084c293. It stopped at **identify**, before backup or flash,
with `Error: open failed`. USB enumeration showed no ST-Link device.
Consequently this release has **not been flashed or verified on hardware**.
A reconnect is required to complete the live installation and all-eight-sensor
readback. The earlier 5 ms firmware installations do not validate this release.

Power, range, detection reliability, bus timing, sensor recovery fault injection,
and Windows/Linux hardware installation remain unmeasured.
